
export const toDoActionInput=(givenInput)=>{
    return{
        type:'INPUT_ENTERED',
        payload:givenInput
};
}

export const clearAllAction=()=>{
    return{
        type:'CLREAR_ALL'
    }
}
export const completedAction=(completedaction,completedStatus)=>{
    return{
        type:'COMPLETED_ONE',
        payload:{
            completedTask:completedaction,
            completedStatus:completedStatus
    }
}
}