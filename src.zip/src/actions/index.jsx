
export const toDoActionInput=(givenInput)=>{
    return{
        type:'INPUT_ENTERED',
        payload:givenInput
};
}

export const clearAllAction=()=>{
    return{
        type:'CLREAR_ALL'
    }
}
export const completedAction=(completedaction)=>{
    return{
        type:'COMPLETED_ONE',
        payload:completedaction
    }
}