import React from 'react';
import { connect } from 'react-redux';

class CompletedList extends React.Component{
    renderHelper=()=>{
        return this.props.completed.length === 0 ? <p></p> : this.props.completed.map(value=>{
            console.log('taken completed task to'+value);
            return (
                <h1>{value}</h1>
            );
        }

        );
    }
    render(){
        return(
            <div>
                {this.renderHelper()}
            </div>
        );
    }
}

const mapStateToProps=(state)=>{
    return {completed:state.completed};
}

export default connect(mapStateToProps)(CompletedList);