import React from 'react';

import {completedAction} from '../actions';

import {connect} from 'react-redux';
class DisplayTask extends React.Component{
    renderHelper=()=>{
        if(this.props.inp.length===0){
            return(<h1>Enter the text</h1>);
        }else{
            return this.props.inp.map(input=>{
            
            return(
                <div>
                    {/* <h1>{input.searchText}</h1> */}
                  <input type='checkbox' name={input} onChange={this.onDo} /><p>{input}</p>
                </div>
            );
        });
        }

        // return this.props.inp.length === 0 ? <h2>Enter the action Item</h2> : this.props.inp.map(inp=>{
        //     return <h2>{inp.searchText}</h2>
        // })
        
    }
    onDo=(r)=>{
        let d=r.target.name;
        let dd=r.target.checked
        
        this.props.completedAction(d,dd);
    }
   
    render(){
        // console.log("---"+this.props.inp);
        return(
            <div>
                {this.renderHelper()}
            </div>
        );
    }
}
const mapStateToProps=(state)=>{
    
    return{inp:state.all};
}
export default connect(mapStateToProps,{completedAction})(DisplayTask);