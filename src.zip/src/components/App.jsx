import React from 'react';
import UserInputField from './UserInputField';

class App extends React.Component{
    render(){
        return(
            <div>
                <UserInputField />
            </div>
        );
    }
}
export default App;
