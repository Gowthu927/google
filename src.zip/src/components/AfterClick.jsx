import React from 'react';


class AfterClick extends React.Component{
    render(){
        return();
    }
}