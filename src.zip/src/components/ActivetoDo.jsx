import React from 'react';

import { connect } from 'react-redux';

class ActivetoDo extends React.Component{
    renderHelper=()=>{
        return this.props.active.length === 0 ? <p>no active items</p> : this.props.active.map(value=>{
            console.log('taken active task to'+value);
            return (
                <h1>{value}</h1>
            );
        }

        );
    }
    render(){
        return(
            <div>
                {this.renderHelper()}
            </div>
        );
    }
}

const mapStateToProps=(state)=>{
    return {active:state.active};
}

export default connect(mapStateToProps)(ActivetoDo);

