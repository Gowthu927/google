import React from 'react';
import DisplayTask from './DisplayTask';
import CompletedList from './CompletedList';
import {toDoActionInput,clearAllAction} from '../actions';

import {connect} from 'react-redux';
import ActivetoDo from './ActivetoDo';

class UserInputField extends React.Component{

    state={
        allShow:true,
        allCompleted:true,
        allActive:true
    }
    componentDidMount=()=>{
        this.setState({allShow:true});
        this.setState({allCompleted:false});
        this.setState({allActive:false});
    }

    onFormSubmit=(event)=>{
        event.preventDefault();
        let inp={};
        for (let data in this.refs){
            inp[data]=this.refs[data].value;
        }
        // console.log(inp);
        // console.log(this.props); 
        this.props.toDoActionInput(inp.searchText);
    }
    onAllClear=()=>{
        this.props.clearAllAction();
    }
    toSeeCompleted=()=>{
        this.setState({allShow:false});
        this.setState({allCompleted:true});
        this.setState({allActive:false});
        
    }
    toSeeAll=()=>{
        this.setState({allShow:true});
        this.setState({allCompleted:false});
        this.setState({allActive:false});
        
        console.log(this.state.allShow);
    }
    toSeeActive=()=>{
        this.setState({allShow:false});
        this.setState({allCompleted:false});
        this.setState({allActive:true});
        
    }

    render(){
        return(
            <div>
            <div>
                <form onSubmit={this.onFormSubmit}>
                    <label>
                        Enter the task to do :
                    </label>
                    <input type='text' ref='searchText' />
                    <button>Add</button>
                </form>
                
            </div>
           
            <div>

            </div>
            {/* <div>
            <CompletedList />
            </div> */}
            <div>
                {this.state.allShow && <DisplayTask />}
                {this.state.allCompleted && <CompletedList />}
        {this.state.allActive && <ActivetoDo  /> }
            </div>
            <div>
                <button onClick={this.toSeeAll}>All</button>
                <button onClick={this.toSeeActive}>Active</button>
                <button onClick={this.toSeeCompleted}>Completed</button>
                <button onClick={this.onAllClear}>Clear All</button>
            </div>
            </div>
        )
    }
}

// const mapStateToProps=(state)=>{
//     console.log(state)
//     return{ip:state.enteredInput};
// }
export default connect(null,{
    toDoActionInput:toDoActionInput,
    clearAllAction:clearAllAction
})(UserInputField);