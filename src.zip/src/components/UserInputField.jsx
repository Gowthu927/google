import React from 'react';
import DisplayTask from './DisplayTask';
import CompletedList from './CompletedList';
import {toDoActionInput,clearAllAction} from '../actions';

import {connect} from 'react-redux';

class UserInputField extends React.Component{

    onFormSubmit=(event)=>{
        event.preventDefault();
        let inp={};
        for (let data in this.refs){
            inp[data]=this.refs[data].value;
        }
        // console.log(inp);
        // console.log(this.props);
        this.props.toDoActionInput(inp);
    }
    onAllClear=()=>{
        this.props.clearAllAction();
    }
    toSeeCompleted=()=>{
        
    }

    render(){
        return(
            <div>
            <div>
                <form onSubmit={this.onFormSubmit}>
                    <label>
                        Enter the task to do :
                    </label>
                    <input type='text' ref='searchText' />
                    <button>Add</button>
                </form>
                
            </div>
            <div>
                <DisplayTask />
                
            </div>
            <div>
            <CompletedList />
            </div>
            <div>
                <button>All</button>
                <button>Active</button>
                <button onClick={this.toSeeCompleted}>Completed</button>
                <button onClick={this.onAllClear}>Clear All</button>
            </div>
            </div>
        )
    }
}

// const mapStateToProps=(state)=>{
//     console.log(state)
//     return{ip:state.enteredInput};
// }
export default connect(null,{
    toDoActionInput:toDoActionInput,
    clearAllAction:clearAllAction
})(UserInputField);