export default (state=[],action)=>{
    switch(action.type){
        case 'INPUT_ENTERED':
            return [...state,action.payload];
        case 'CLREAR_ALL':
            return [];
        case 'COMPLETED_ONE':
                switch (action.payload.completedStatus) {
                    case true:
                        return state.filter(c=>c!==action.payload.completedTask);
                    case false:
                        return [...state,action.payload.completedTask];
                    default:
                        return state;
                }
        default:
            return state;
    }
}