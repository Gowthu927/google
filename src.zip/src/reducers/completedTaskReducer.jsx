export default (state=[],action)=>{
    switch (action.type) {
        case 'COMPLETED_ONE':
            return [...state,action.payload];
        case 'CLREAR_ALL':
            return [];
    
        default:
            return state;
    }
}