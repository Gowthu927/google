export default (state=[],action)=>{
    switch (action.type) {
        case 'COMPLETED_ONE':
            switch (action.payload.completedStatus) {
                case true:
                    return [...state,action.payload.completedTask];
            
                case false:
                    return state.filter(c=>c!==action.payload.completedTask);
                default:
                    return state;
            }
        case 'CLREAR_ALL':
            return [];
    
        default:
            return state;
    }
}