import {combineReducers} from 'redux';
import toDoActionInputReducer from './toDoActionInputReducer';
import completedTaskReducer from './completedTaskReducer';

export default combineReducers({
    all:toDoActionInputReducer,
    completed:completedTaskReducer

});
