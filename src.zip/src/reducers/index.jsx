import {combineReducers} from 'redux';
import toDoActionInputReducer from './toDoActionInputReducer';
import completedTaskReducer from './completedTaskReducer';
import toShowActiveReducer from './toShowActiveReducer';

export default combineReducers({
    all:toDoActionInputReducer,
    completed:completedTaskReducer,
    active:toShowActiveReducer

});
