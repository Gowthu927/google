export default (state=[],action)=>{
    switch(action.type){
        case 'INPUT_ENTERED':
            return [...state,action.payload];
        case 'CLREAR_ALL':
            return [];
        case 'COMPLETED_ONE':
            return state.filter(value=>value!==action.payload);
        default:
            return state;
    }
}