


export default (state=[],action)=>{
    switch (action.type) {
        case 'INPUT_ENTERED':
            return [...state,action.payload];
        case 'CLREAR_ALL':
                    return [];
    
        default:
            return state;
    }
}